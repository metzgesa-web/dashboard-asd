"""
Module de Tunnel HTTPS Automatique (Cloudflare Quick Tunnel / Named Tunnel + Canal Permanent ntfy.sh)
pour l'AS Durlinsdorf (Depuis 1969).

Fonctionnalités 100 % en espace utilisateur (AUCUN `sudo` ni droit administrateur requis) :
1. Détecte automatiquement l'OS et l'architecture matérielle :
   - Windows PC (`amd64` / `x86`)
   - Raspberry Pi Linux (`aarch64` / `arm64`, `armv7l` / `armhf` / `arm`, `x86_64`)
2. Télécharge automatiquement le binaire officiel `cloudflared` dans `./bin/` s'il est absent.
3. Démarre et supervise en tâche de fond `cloudflared tunnel --url http://127.0.0.1:<PORT>`
   (ou un tunnel nommé si un Token Cloudflare ou Ngrok est configuré dans `/admin`).
4. Extrait l'URL publique HTTPS (`https://xxxx.trycloudflare.com`), surveille l'état du processus
   et le relance automatiquement en cas de coupure Internet.
5. Publie automatiquement chaque nouvelle URL HTTPS sur le canal permanent `https://ntfy.sh/<topic>`
   du club pour offrir une adresse fixe permanente sans création de compte.
"""

from __future__ import annotations

import datetime
import json
import logging
import os
import platform
import re
import socket
import stat
import struct
import subprocess
import threading
import time
from typing import Any, Callable, Dict, Optional

import requests
import urllib3
import urllib3.util.connection as urllib3_cn

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
urllib3_cn.allowed_gai_family = lambda: socket.AF_INET

logger = logging.getLogger("ASD_Remote_Tunnel")

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
BIN_DIR = os.path.join(BASE_DIR, "bin")
TUNNEL_LOG_PATH = os.path.join(BASE_DIR, "tunnel.log")
TUNNEL_JSON_NTFY_TOPIC = "asd-durlinsdorf-tunnel-1969"

TRYCLOUDFLARE_REGEX = re.compile(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com")


def get_cloudflared_download_info() -> tuple[str, str]:
    """
    Détermine l'URL officielle GitHub de `cloudflared` et le nom du binaire local
    selon le système d'exploitation et `uname -m` sur Raspberry Pi :
      - `aarch64` -> `cloudflared-linux-arm64`
      - `armv7l` ou `armv6l` (32-bit) -> `cloudflared-linux-arm`
    """
    system = platform.system().lower()
    machine = platform.machine().lower()
    if hasattr(os, "uname"):
        try:
            machine = os.uname().machine.strip().lower()
        except Exception:
            pass
    bits = struct.calcsize("P") * 8

    base_gh = "https://github.com/cloudflare/cloudflared/releases/latest/download"

    if system == "windows":
        if "64" in machine or bits == 64:
            asset = "cloudflared-windows-amd64.exe"
        else:
            asset = "cloudflared-windows-386.exe"
        local_name = "cloudflared.exe"
    elif system == "linux":
        # Supprime tout binaire Windows .exe éventuellement présent par erreur
        win_exe = os.path.join(BIN_DIR, "cloudflared.exe")
        if os.path.exists(win_exe):
            try:
                os.remove(win_exe)
            except OSError:
                pass

        if machine in ("aarch64", "arm64"):
            asset = "cloudflared-linux-arm64"
            local_name = "cloudflared-linux-arm64"
        elif machine in ("armv7l", "armv6l") or "arm" in machine:
            asset = "cloudflared-linux-arm"
            local_name = "cloudflared-linux-arm"
        elif machine in ("x86_64", "amd64"):
            asset = "cloudflared-linux-amd64"
            local_name = "cloudflared-linux-amd64"
        else:
            asset = "cloudflared-linux-386"
            local_name = "cloudflared-linux-386"
    elif system == "darwin":
        asset = "cloudflared-darwin-amd64.tgz"
        local_name = "cloudflared-darwin"
    else:
        asset = "cloudflared-linux-arm"
        local_name = "cloudflared"

    return f"{base_gh}/{asset}", os.path.join(BIN_DIR, local_name)


def ensure_cloudflared_binary() -> Optional[str]:
    """
    Vérifie la présence du binaire `cloudflared` dans `./bin/` et le télécharge
    automatiquement en espace utilisateur s'il est absent.
    """
    os.makedirs(BIN_DIR, exist_ok=True)
    download_url, binary_path = get_cloudflared_download_info()

    if os.path.exists(binary_path) and os.path.getsize(binary_path) > 1_000_000:
        if platform.system().lower() != "windows":
            try:
                st = os.stat(binary_path)
                os.chmod(binary_path, st.st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
            except OSError:
                pass
        return binary_path

    logger.info("Téléchargement automatique de cloudflared depuis %s ...", download_url)
    tmp_path = f"{binary_path}.part"
    try:
        with requests.get(download_url, stream=True, timeout=60, verify=False) as resp:
            resp.raise_for_status()
            with open(tmp_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=65536):
                    if chunk:
                        f.write(chunk)
        os.replace(tmp_path, binary_path)
        if platform.system().lower() != "windows":
            st = os.stat(binary_path)
            os.chmod(binary_path, st.st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
        logger.info("Binaire cloudflared installé avec succès dans %s", binary_path)
        return binary_path
    except Exception as exc:
        logger.error("Échec du téléchargement de cloudflared : %s", exc)
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        return None


def check_internet_alive(timeout: float = 3.0) -> bool:
    """Vérifie rapidement si la connexion Internet du Club-House est active."""
    for host, port in (("1.1.1.1", 443), ("8.8.8.8", 53)):
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except OSError:
            continue
    return False


def disable_wifi_power_save() -> None:
    """Désactive la mise en veille Wi-Fi sur Raspberry Pi pour maintenir le tunnel 24h/24."""
    if platform.system().lower() != "linux":
        return
    for cmd in (
        ["iw", "dev", "wlan0", "set", "power_save", "off"],
        ["iwconfig", "wlan0", "power", "off"],
        ["sudo", "-n", "iw", "dev", "wlan0", "set", "power_save", "off"],
        ["sudo", "-n", "iwconfig", "wlan0", "power", "off"],
    ):
        try:
            subprocess.run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=3,
                check=False,
            )
        except Exception:
            pass


def publish_tunnel_json_to_ntfy(
    public_admin_url: str,
    local_admin_url: str,
    mdns_admin_url: str = "",
    json_topic: str = TUNNEL_JSON_NTFY_TOPIC,
) -> bool:
    """
    Publie un objet JSON pur sur `https://ntfy.sh/asd-durlinsdorf-tunnel-1969`
    (interrogé par `portail_admin_permanent.html` via `/json?poll=1` pour rediriger
    automatiquement les smartphones vers l'URL `/admin` active).
    """
    if not public_admin_url or not json_topic:
        return False

    topic_clean = json_topic.strip().strip("/")
    ntfy_url = f"https://ntfy.sh/{topic_clean}"
    now_str = datetime.datetime.now().strftime("%d/%m/%Y à %H:%M:%S")

    payload = {
        "club": "AS Durlinsdorf 1969",
        "public_admin_url": public_admin_url,
        "public_base_url": public_admin_url.replace("/admin", ""),
        "local_admin_url": local_admin_url,
        "mdns_admin_url": mdns_admin_url,
        "updated_at": now_str,
        "timestamp": int(time.time()),
    }

    try:
        resp = requests.post(
            ntfy_url,
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers={
                "Title": "ASD Tunnel JSON Endpoint",
                "Priority": "default",
                "Tags": "link",
            },
            timeout=10,
            verify=False,
        )
        if resp.status_code in (200, 201, 202):
            logger.info("JSON Tunnel publié sur https://ntfy.sh/%s", topic_clean)
            return True
    except Exception as exc:
        logger.warning("Impossible de publier le JSON tunnel sur ntfy.sh : %s", exc)
    return False


def publish_to_ntfy(
    ntfy_topic: str,
    public_admin_url: str,
    local_admin_url: str,
    mdns_admin_url: str = "",
    is_reconnect: bool = False,
) -> bool:
    """
    Envoie une notification prioritaire sur le canal permanent `https://ntfy.sh/<ntfy_topic>`
    ET publie le JSON de redirection automatique sur `https://ntfy.sh/asd-durlinsdorf-tunnel-1969`.
    """
    publish_tunnel_json_to_ntfy(
        public_admin_url=public_admin_url,
        local_admin_url=local_admin_url,
        mdns_admin_url=mdns_admin_url,
    )

    if not ntfy_topic or not public_admin_url:
        return False

    topic_clean = ntfy_topic.strip().strip("/")
    ntfy_url = f"https://ntfy.sh/{topic_clean}"
    now_str = datetime.datetime.now().strftime("%d/%m/%Y à %H:%M:%S")

    wifi_line = f"{local_admin_url}" + (f" (ou {mdns_admin_url})" if mdns_admin_url else "")
    message = (
        f"🏟️ AS Durlinsdorf (Depuis 1969)\n"
        f"⏱️ Reconnexion / Démarrage à : {now_str}\n\n"
        f"🌐 Lien direct 4G / Internet :\n{public_admin_url}\n\n"
        f"📶 Lien Wi-Fi Club-House :\n{wifi_line}\n\n"
        f"🔐 Code PIN par défaut : 1969"
    )

    headers = {
        "Title": f"AS Durlinsdorf - Accès Admin TV ({now_str})",
        "Priority": "high",
        "Tags": "soccer,tv,key",
        "Click": public_admin_url,
        "Actions": f"view, Ouvrir Admin 4G, {public_admin_url}; view, Wi-Fi Local, {local_admin_url}",
    }

    try:
        resp = requests.post(
            ntfy_url,
            data=message.encode("utf-8"),
            headers=headers,
            timeout=10,
            verify=False,
        )
        if resp.status_code in (200, 201, 202):
            logger.info("Notification publiée sur le canal fixe https://ntfy.sh/%s", topic_clean)
            return True
        logger.warning("Réponse ntfy.sh inattendue (%d) : %s", resp.status_code, resp.text[:120])
    except Exception as exc:
        logger.warning("Impossible de publier sur ntfy.sh (%s) : %s", ntfy_url, exc)

    return False


class RemoteTunnelManager:
    """
    Superviseur du tunnel HTTPS en tâche de fond (24h/24 sans changement d'URL ni blocage PIPE) :
    - Redirige la sortie de `cloudflared` vers `tunnel.log` (aucun `subprocess.PIPE` susceptible de saturer le buffer OS de 64 Ko).
    - Ne tue JAMAIS `cloudflared` lors des vérifications réseau (`cloudflared` maintient la même URL avec `--ha-connections 4 --heartbeat-interval 5s`).
    - Thread Keep-Alive toutes les 2 minutes + publication JSON toutes les heures sur `ntfy.sh/asd-durlinsdorf-tunnel-1969`.
    - Ne relance `cloudflared` QUE si le processus Linux est réellement mort (`proc.poll() is not None`).
    """

    def __init__(
        self,
        local_port: int = 5000,
        on_url_change: Optional[Callable[[str], None]] = None,
        get_settings_fn: Optional[Callable[[], Dict[str, Any]]] = None,
    ) -> None:
        self.local_port = local_port
        self.on_url_change = on_url_change
        self.get_settings_fn = get_settings_fn

        self.public_base_url: str = ""
        self.registered: bool = False
        self.status: str = "starting"  # starting | online | reconnecting | error
        self.last_error: str = ""
        self.started_at: str = ""
        self.last_ntfy_sent_url: str = ""
        self.internet_online: bool = True
        self._last_hourly_ntfy_epoch: float = 0.0

        self._proc: Optional[subprocess.Popen] = None
        self._lock = threading.RLock()
        self._stop_event = threading.Event()
        self._restart_requested = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._keepalive_thread: Optional[threading.Thread] = None

    def get_info(self, ntfy_topic: str = "") -> Dict[str, Any]:
        """Retourne l'état courant du tunnel distant pour l'API et `/admin`."""
        with self._lock:
            settings = self.get_settings_fn() if self.get_settings_fn else {}
            custom_domain = str(settings.get("custom_remote_domain") or "").strip().rstrip("/")
            active_base = self.public_base_url if self.registered else ""
            effective_base = custom_domain if custom_domain else active_base
            admin_url = f"{effective_base}/admin" if effective_base else ""
            topic = ntfy_topic or str(settings.get("ntfy_topic") or "").strip()
            ntfy_url = f"https://ntfy.sh/{topic}" if topic else ""

            return {
                "status": self.status,
                "registered": self.registered,
                "public_base_url": effective_base,
                "trycloudflare_url": active_base,
                "public_admin_url": admin_url,
                "ntfy_topic": topic,
                "ntfy_url": ntfy_url,
                "json_ntfy_topic": TUNNEL_JSON_NTFY_TOPIC,
                "json_ntfy_url": f"https://ntfy.sh/{TUNNEL_JSON_NTFY_TOPIC}",
                "started_at": self.started_at,
                "last_error": self.last_error,
                "has_custom_token": bool(str(settings.get("cloudflare_tunnel_token") or "").strip()),
                "custom_remote_domain": custom_domain,
            }

    def start(self) -> None:
        """Démarre le superviseur `cloudflared` et le thread Keep-Alive (2 min)."""
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        disable_wifi_power_save()
        self._thread = threading.Thread(target=self._supervisor_loop, daemon=True, name="ASD_Cloudflared_Tunnel")
        self._thread.start()
        self._keepalive_thread = threading.Thread(target=self._keepalive_loop, daemon=True, name="ASD_Tunnel_KeepAlive_2m")
        self._keepalive_thread.start()

    def _keepalive_loop(self) -> None:
        """
        Thread Keep-Alive (toutes les 2 minutes) :
        - Désactive la mise en veille Wi-Fi.
        - Effectue une requête HTTP légère toutes les 2 minutes sur l'URL publique du tunnel
          pour empêcher Cloudflare ou la box de fermer le tunnel pour inactivité.
        - Ne tue JAMAIS le processus `cloudflared` (il gère ses propres reconnexions en gardant la même URL).
        """
        while not self._stop_event.is_set():
            time.sleep(120)
            if self._stop_event.is_set():
                break

            disable_wifi_power_save()

            with self._lock:
                current_url = self.public_base_url if self.registered else ""
                proc_alive = self._proc is not None and self._proc.poll() is None

            if not proc_alive or not current_url:
                continue

            # Requête Keep-Alive légère sur l'URL publique du tunnel (sans jamais tuer cloudflared en cas de micro-coupure)
            try:
                requests.get(f"{current_url}/api/state", timeout=10, verify=False)
            except Exception as exc:
                logger.debug("Keep-Alive 2m (tunnel maintenu par cloudflared) : %s", exc)

    def request_restart(self) -> None:
        """Force le redémarrage du tunnel uniquement sur action manuelle explicite (changement de token)."""
        self._restart_requested.set()
        self._terminate_process()

    def stop(self) -> None:
        """Arrête proprement le sous-processus `cloudflared`."""
        self._stop_event.set()
        self._terminate_process()

    def _terminate_process(self) -> None:
        with self._lock:
            proc = self._proc
            self._proc = None
        if proc is not None:
            try:
                proc.terminate()
                proc.wait(timeout=4)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

    def _build_command(self, binary_path: str) -> list[str]:
        settings = self.get_settings_fn() if self.get_settings_fn else {}
        cf_token = str(settings.get("cloudflare_tunnel_token") or "").strip()
        if cf_token:
            return [
                binary_path,
                "tunnel",
                "--protocol",
                "http2",
                "--ha-connections",
                "4",
                "--heartbeat-interval",
                "5s",
                "--no-autoupdate",
                "run",
                "--token",
                cf_token,
            ]
        return [
            binary_path,
            "tunnel",
            "--protocol",
            "http2",
            "--ha-connections",
            "4",
            "--heartbeat-interval",
            "5s",
            "--no-autoupdate",
            "--url",
            f"http://127.0.0.1:{self.local_port}",
        ]

    def _supervisor_loop(self) -> None:
        """
        Lance `cloudflared` avec redirection directe vers `tunnel.log` (aucun `subprocess.PIPE` !).
        Ne relance `cloudflared` QUE si le processus OS est réellement mort (`proc.poll() is not None`).
        """
        while not self._stop_event.is_set():
            self._restart_requested.clear()
            with self._lock:
                self.public_base_url = ""
                self.registered = False
                self.status = "starting"

            binary_path = ensure_cloudflared_binary()
            if not binary_path:
                with self._lock:
                    self.status = "error"
                    self.last_error = "Impossible de télécharger cloudflared (vérifiez la connexion Internet)."
                time.sleep(5)
                continue

            cmd = self._build_command(binary_path)
            logger.info("Lancement du tunnel HTTPS 24/7 (tunnel.log) : %s", " ".join(cmd))

            creationflags = 0
            if platform.system().lower() == "windows":
                creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

            pending_url = ""
            tunnel_registered = False
            announced = False
            log_writer = None
            log_reader = None

            try:
                # Écriture directe dans tunnel.log : aucun buffer PIPE OS de 64 Ko ne peut jamais bloquer cloudflared
                log_writer = open(TUNNEL_LOG_PATH, "w", encoding="utf-8", errors="replace", buffering=1)
                proc = subprocess.Popen(
                    cmd,
                    stdout=log_writer,
                    stderr=subprocess.STDOUT,
                    stdin=subprocess.DEVNULL,
                    creationflags=creationflags,
                )
                with self._lock:
                    self._proc = proc

                settings = self.get_settings_fn() if self.get_settings_fn else {}
                custom_dom = str(settings.get("custom_remote_domain") or "").strip().rstrip("/")
                if custom_dom and str(settings.get("cloudflare_tunnel_token") or "").strip():
                    pending_url = custom_dom

                log_reader = open(TUNNEL_LOG_PATH, "r", encoding="utf-8", errors="replace")

                # Boucle de surveillance passive tant que le processus Linux/OS cloudflared est en vie
                while proc.poll() is None and not self._stop_event.is_set() and not self._restart_requested.is_set():
                    line = log_reader.readline()
                    if line:
                        if not announced:
                            match = TRYCLOUDFLARE_REGEX.search(line)
                            if match:
                                found_url = match.group(0).rstrip("/")
                                if "api.trycloudflare.com" not in found_url:
                                    pending_url = found_url
                                    logger.info("URL Quick Tunnel détectée dans tunnel.log : %s", pending_url)

                            if "registered tunnel connection" in line.lower():
                                tunnel_registered = True
                                logger.info("Confirmation Edge Cloudflare : Registered tunnel connection.")

                            if pending_url and tunnel_registered:
                                announced = True
                                self._handle_discovered_url(pending_url)
                    else:
                        # Aucune nouvelle ligne : pause légère et troncature préventive si tunnel.log > 2 Mo
                        if announced:
                            try:
                                if os.path.getsize(TUNNEL_LOG_PATH) > 2_000_000:
                                    log_writer.seek(0)
                                    log_writer.truncate(0)
                                    log_reader.seek(0)
                            except OSError:
                                pass
                        time.sleep(0.5 if not announced else 2.0)

                if self._stop_event.is_set() or self._restart_requested.is_set():
                    self._terminate_process()
                else:
                    exit_code = proc.poll()
                    logger.warning("Le processus cloudflared s'est arrêté (code=%s). Relance immédiate...", exit_code)
            except Exception as exc:
                with self._lock:
                    self.public_base_url = ""
                    self.registered = False
                    self.status = "reconnecting"
                    self.last_error = str(exc)
                logger.warning("Erreur superviseur cloudflared (%s), relance...", exc)
            finally:
                for fh in (log_reader, log_writer):
                    if fh is not None:
                        try:
                            fh.close()
                        except Exception:
                            pass
                self._terminate_process()
                with self._lock:
                    self.public_base_url = ""
                    self.registered = False
                    if not self._stop_event.is_set():
                        self.status = "reconnecting"

            if not self._stop_event.is_set():
                time.sleep(3)

    def _handle_discovered_url(self, new_base_url: str) -> None:
        changed = False
        with self._lock:
            if self.public_base_url != new_base_url or not self.registered or self.status != "online":
                self.public_base_url = new_base_url
                self.registered = True
                self.status = "online"
                self.last_error = ""
                self.started_at = datetime.datetime.now().strftime("%d/%m/%Y à %H:%M:%S")
                changed = True

        if changed:
            logger.info("=================================================================")
            logger.info(" TUNNEL HTTPS PUBLIC ACTIF (4G / INTERNET) :")
            logger.info(" -> Admin 4G/Partout : %s/admin", new_base_url)
            logger.info("=================================================================")
            if self.on_url_change:
                try:
                    self.on_url_change(new_base_url)
                except Exception as exc:
                    logger.warning("Erreur callback on_url_change : %s", exc)
