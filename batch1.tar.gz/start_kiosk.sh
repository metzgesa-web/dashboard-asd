#!/usr/bin/env bash
# Script de démarrage autonome (Serveur + Kiosk TV 1080p) — AS Durlinsdorf
# Corrige l'écran blanc, désactive la bulle de traduction et stabilise cloudflared

APP_DIR="${APP_DIR:-$HOME/asd-dashboard}"
PORT="${PORT:-5000}"

cd "$APP_DIR"

if [ -x "$APP_DIR/venv/bin/python" ]; then
    PYTHON_EXEC="$APP_DIR/venv/bin/python"
else
    PYTHON_EXEC="python3"
fi

if command -v chromium >/dev/null 2>&1; then
    CHROMIUM_BIN="chromium"
elif command -v chromium-browser >/dev/null 2>&1; then
    CHROMIUM_BIN="chromium-browser"
else
    CHROMIUM_BIN="chromium-browser"
fi

# 1. Supprimer unclutter -root et tout binaire Windows .exe inutile
pkill -9 unclutter 2>/dev/null || true
mkdir -p "$APP_DIR/bin"
rm -f "$APP_DIR/bin/cloudflared.exe" 2>/dev/null || true
chmod +x "$APP_DIR/bin/cloudflared"* 2>/dev/null || true

# 2. Détecter l'affichage graphique actif (X11 et/ou Wayland sur Raspberry Pi OS Bookworm)
export DISPLAY="${DISPLAY:-:0}"
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
if [ -z "${WAYLAND_DISPLAY:-}" ]; then
    for wl_sock in wayland-0 wayland-1; do
        if [ -S "$XDG_RUNTIME_DIR/$wl_sock" ]; then
            export WAYLAND_DISPLAY="$wl_sock"
            break
        fi
    done
fi

# 3. Si une mise à jour vient d'être extraite (fichier .update_flag présent), redémarrer proprement app.py + cloudflared
if [ -f "$APP_DIR/.update_flag" ]; then
    rm -f "$APP_DIR/.update_flag"
    if sudo -n true 2>/dev/null && [ -f /etc/systemd/system/asd-dashboard.service ]; then
        if ! grep -q "KillMode=process" /etc/systemd/system/asd-dashboard.service 2>/dev/null; then
            sudo -n sed -i '/^Type=simple/a KillMode=process' /etc/systemd/system/asd-dashboard.service 2>/dev/null || true
            sudo -n systemctl daemon-reload 2>/dev/null || true
        fi
    fi
    pkill -9 -f "cloudflared" 2>/dev/null || true
    pkill -9 -f "app.py" 2>/dev/null || true
    sleep 1
    if sudo -n true 2>/dev/null && systemctl is-enabled --quiet asd-dashboard.service 2>/dev/null; then
        sudo -n systemctl restart asd-dashboard.service 2>/dev/null || true
    elif systemctl --user is-enabled --quiet asd-dashboard.service 2>/dev/null; then
        systemctl --user restart asd-dashboard.service 2>/dev/null || true
    else
        nohup "$PYTHON_EXEC" "$APP_DIR/app.py" > "$APP_DIR/server.log" 2>&1 &
    fi
    sleep 2
else
    sleep 2
fi

# 4. Si le serveur Flask ne tourne pas encore sur le port $PORT, le démarrer en tâche de fond
if ! curl -fsS -o /dev/null "http://127.0.0.1:$PORT/api/state" 2>/dev/null; then
    nohup "$PYTHON_EXEC" "$APP_DIR/app.py" > "$APP_DIR/server.log" 2>&1 &
fi

# 5. Attendre que la page /tv réponde HTTP 200 avant d'ouvrir Chromium
for i in $(seq 1 45); do
    if curl -fsS -o /dev/null "http://127.0.0.1:$PORT/tv" 2>/dev/null; then
        break
    fi
    sleep 1
done

# 6. Désactiver la mise en veille de l'écran (sans unclutter -root)
if [ -n "${DISPLAY:-}" ]; then
    xset s off 2>/dev/null || true
    xset -dpms 2>/dev/null || true
    xset s noblank 2>/dev/null || true
fi

# 7. Fermer toute ancienne instance bloquée de Chromium et préconfigurer la langue FR sans traduction
pkill -f "asd-kiosk-profile" 2>/dev/null || true
pkill -9 chromium 2>/dev/null || true
pkill -9 chromium-browser 2>/dev/null || true
rm -rf /tmp/asd-kiosk-profile "$HOME/.config/chromium/Singleton"* "$HOME/.cache/chromium/Default/GPUCache" 2>/dev/null || true
mkdir -p /tmp/asd-kiosk-profile/Default
printf '%s\n' '{"translate":{"enabled":false},"translate_blocked_languages":["fr","fr-FR","en","en-US","de"],"intl":{"accept_languages":"fr-FR,fr"},"profile":{"exit_type":"Normal","exited_cleanly":true}}' > /tmp/asd-kiosk-profile/Default/Preferences

export LANG="fr_FR.UTF-8"
export LANGUAGE="fr_FR:fr"

# 8. Lancer Chromium en mode Kiosk sans bulle de traduction et sans bug GPU VC4
exec "$CHROMIUM_BIN" \
    --user-data-dir=/tmp/asd-kiosk-profile \
    --kiosk \
    --app="http://127.0.0.1:$PORT/tv?v=$(date +%s)" \
    --lang=fr \
    --accept-lang=fr-FR,fr \
    --disable-translate \
    --disable-features=Translate,TranslateUI,TranslateSubFrames \
    --disable-gpu \
    --disable-gpu-compositing \
    --disable-software-rasterizer \
    --password-store=basic \
    --no-first-run \
    --no-default-browser-check \
    --noerrdialogs \
    --disable-infobars \
    --disable-session-crashed-bubble \
    --disable-restore-session-state \
    --check-for-update-interval=31536000 \
    --autoplay-policy=no-user-gesture-required \
    --start-fullscreen \
    "http://127.0.0.1:$PORT/tv?v=$(date +%s)"
