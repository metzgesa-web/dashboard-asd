"""
Application Principale Flask — Affichage Dynamique (Digital Signage)
Club-House de l'AS Durlinsdorf (Fondé en 1969 — Affiliation FFF #523732)

Fonctionnalités :
- Vue TV 1080p Zero-Scroll (`/tv` et `/`) avec mise à jour temps réel via SSE (`/api/stream`) + Polling (`/api/state`)
- Interface Mobile-First d'Administration (`/admin`) protégée par code PIN (défaut : 1969)
- Détection automatique de l'IP locale du Raspberry Pi et génération dynamique du QR Code (`/api/qrcode.png`)
- Proxy météo Open-Meteo pour Durlinsdorf (lat 47.486, lon 7.241) avec cache hors-ligne (`/api/weather`)
- Planificateur en tâche de fond pour la synchronisation FFF automatique (toutes les 30 min le week-end après-midi,
  toutes les 2h en semaine) + synchronisation manuelle à la demande.
- Stockage JSON local avec écriture atomique (`database.json`) résistant aux coupures électriques.
"""

from __future__ import annotations

import base64
import copy
import datetime
import io
import json
import logging
import os
import queue
import socket
import threading
import time
import uuid
from functools import wraps
from typing import Any, Callable, Dict, List, Optional

import qrcode
import requests
from flask import (
    Flask,
    Response,
    jsonify,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)
from werkzeug.utils import secure_filename

from fff_scraper import FFFScraper, is_asd_team_name, should_auto_sync
from remote_tunnel import (
    TUNNEL_JSON_NTFY_TOPIC,
    RemoteTunnelManager,
    publish_to_ntfy,
    publish_tunnel_json_to_ntfy,
)

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("ASD_App")

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "database.json")
PRINTABLE_QR_PATH = os.path.join(BASE_DIR, "qr_code_imprimable.html")
PORTAIL_PERMANENT_PATH = os.path.join(BASE_DIR, "portail_admin_permanent.html")
CLUB_LOGO_PATH = os.path.join(BASE_DIR, "static", "logo_asd.png")
UPLOAD_SPONSORS_DIR = os.path.join(BASE_DIR, "static", "uploads", "sponsors")
UPLOAD_EVENTS_DIR = os.path.join(BASE_DIR, "static", "uploads", "events")

os.makedirs(UPLOAD_SPONSORS_DIR, exist_ok=True)
os.makedirs(UPLOAD_EVENTS_DIR, exist_ok=True)

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "svg", "webp", "gif"}

app = Flask(__name__)
app.secret_key = os.environ.get("ASD_SECRET_KEY", "asd-durlinsdorf-1969-stade-grumbach-secret-key")
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16 Mo max par upload image
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0

# Verrou global et gestion d'état temps réel (SSE + Polling)
db_lock = threading.RLock()
state_version = int(time.time() * 1000)
sse_clients: List[queue.Queue] = []
sse_lock = threading.Lock()

# Cache météo en mémoire (rafraîchi toutes les 15 minutes) — 100 % SVG vectoriel (aucun emoji Unicode)
weather_cache: Dict[str, Any] = {
    "timestamp": 0.0,
    "data": {
        "temp": 14,
        "weather_code": 1,
        "description": "Peu nuageux",
        "icon": "partly_cloudy",
        "icon_key": "partly_cloudy",
        "wind_kmh": 8,
        "city": "Durlinsdorf",
        "updated_at": "--:--",
    },
}

# Initialisation du scraper FFF
fff_scraper = FFFScraper()
last_fff_sync_epoch = time.time()


# Cache IP locale & QR Code en mémoire pour des réponses API < 2ms
network_cache: Dict[str, Any] = {
    "timestamp": 0.0,
    "ip": "127.0.0.1",
}
qr_b64_cache: Dict[str, str] = {}

DEFAULT_NTFY_TOPIC = "asd-durlinsdorf-admin-1969"

# État de l'encart QR Code temporaire sur la TV (45s au démarrage, 30s à chaque reconnexion Internet)
SERVER_BOOT_EPOCH = time.time()
qr_overlay_state: Dict[str, Any] = {
    "trigger_id": 1,
    "reason": "boot",
    "duration_seconds": 45,
    "triggered_at": SERVER_BOOT_EPOCH,
}
tv_reload_id = 0

# Protection Anti-Bruteforce sur le Code PIN (5 essais max -> blocage 10 minutes par IP)
MAX_PIN_ATTEMPTS = 5
PIN_LOCKOUT_SECONDS = 600
pin_bruteforce_lock = threading.Lock()
pin_attempts_by_ip: Dict[str, Dict[str, Any]] = {}


# =============================================================================
# UTILITAIRES RÉSEAU, MÉTÉO & BASE DE DONNÉES ATOMIQUE
# =============================================================================
def get_local_ip() -> str:
    """Détecte automatiquement l'adresse IP locale (Wi-Fi / Ethernet) du Raspberry Pi (avec cache 60s)."""
    now = time.time()
    if now - network_cache["timestamp"] < 60 and network_cache["ip"] != "127.0.0.1":
        return network_cache["ip"]

    detected_ip = "127.0.0.1"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.3)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip and not ip.startswith("127."):
            detected_ip = ip
    except Exception:
        pass

    if detected_ip == "127.0.0.1":
        try:
            hostname = socket.gethostname()
            for addr in socket.getaddrinfo(hostname, None, socket.AF_INET):
                ip = addr[4][0]
                if ip and not ip.startswith("127."):
                    detected_ip = ip
                    break
        except Exception:
            pass

    network_cache["ip"] = detected_ip
    network_cache["timestamp"] = now
    return detected_ip


def get_server_port() -> int:
    """Retourne le port d'écoute du serveur Flask."""
    try:
        if request and request.host and ":" in request.host:
            return int(request.host.split(":")[1])
    except Exception:
        pass
    return int(os.environ.get("PORT", 5000))


def get_admin_url() -> str:
    """Construit l'URL complète d'administration locale (IP) pour le QR Code."""
    ip = get_local_ip()
    port = get_server_port()
    if port in (80, 443):
        return f"http://{ip}/admin"
    return f"http://{ip}:{port}/admin"


def get_hostname_local() -> str:
    """Retourne le nom d'hôte mDNS `.local` du Raspberry Pi / PC (ex: `raspberrypi.local`)."""
    try:
        raw_host = socket.gethostname().strip()
        if raw_host:
            short = raw_host.split(".")[0].lower()
            return f"{short}.local"
    except Exception:
        pass
    return "raspberrypi.local"


def get_mdns_admin_url() -> str:
    """Construit l'URL permanente Wi-Fi Club-House mDNS (`http://<nom_hote>.local:5000/admin`)."""
    host_local = get_hostname_local()
    port = get_server_port()
    if port in (80, 443):
        return f"http://{host_local}/admin"
    return f"http://{host_local}:{port}/admin"


def generate_qr_base64(url: str, fill_color: str = "#0B0F17", back_color: str = "#FFD700") -> str:
    """Génère un QR Code haute lisibilité encodé en Base64 PNG (mis en cache par URL)."""
    if not url:
        return ""
    cache_key = f"{url}|{fill_color}|{back_color}"
    if cache_key in qr_b64_cache:
        return qr_b64_cache[cache_key]

    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=8,
        border=2,
    )
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color=fill_color, back_color=back_color)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    b64 = f"data:image/png;base64,{base64.b64encode(buf.getvalue()).decode('ascii')}"
    qr_b64_cache[cache_key] = b64
    return b64


def get_ntfy_topic(db: Optional[Dict[str, Any]] = None) -> str:
    """Retourne le canal unique permanent `ntfy.sh` du club (défaut: `asd-durlinsdorf-admin-1969`)."""
    if db is None:
        db = load_db()
    settings = db.setdefault("settings", {})
    topic = str(settings.get("ntfy_topic") or "").strip()
    if not topic or topic == "asd-durlinsdorf-admin-523732-1969":
        topic = DEFAULT_NTFY_TOPIC
        settings["ntfy_topic"] = topic
        try:
            save_db(db, broadcast=False)
        except Exception:
            pass
    return topic


def generate_printable_qr_html(
    admin_url: Optional[str] = None,
    pin: Optional[str] = None,
    remote_admin_url: Optional[str] = None,
    ntfy_url: Optional[str] = None,
    mdns_admin_url: Optional[str] = None,
) -> str:
    """
    Génère et sauvegarde à la racine du projet le fichier autonome `qr_code_imprimable.html`
    avec 2 QR Codes 100 % PERMANENTS côte à côte qui n'auront jamais besoin d'être réimprimés :
      1. QR Code "Accès 4G / Partout (Permanent)" -> pointe vers `https://ntfy.sh/asd-durlinsdorf-admin-1969`
      2. QR Code "Accès Wi-Fi Club-House" -> pointe vers `http://<NOM_HOTE>.local:5000/admin` (et affiche l'IP locale)
    """
    port = int(os.environ.get("PORT", 5000))
    if not admin_url:
        ip = get_local_ip()
        admin_url = f"http://{ip}/admin" if port in (80, 443) else f"http://{ip}:{port}/admin"
    if not mdns_admin_url:
        host_local = get_hostname_local()
        mdns_admin_url = f"http://{host_local}/admin" if port in (80, 443) else f"http://{host_local}:{port}/admin"
    if not pin:
        pin = get_configured_pin()

    topic = get_ntfy_topic()
    if not ntfy_url:
        ntfy_url = f"https://ntfy.sh/{topic}"

    if remote_admin_url is None and "tunnel_manager" in globals():
        t_info = tunnel_manager.get_info(ntfy_topic=topic)
        remote_admin_url = t_info.get("public_admin_url") or ""

    def _make_print_qr(target_url: str) -> str:
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=12,
            border=2,
        )
        qr.add_data(target_url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="#0B0F17", back_color="#FFFFFF")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return f"data:image/png;base64,{base64.b64encode(buf.getvalue()).decode('ascii')}"

    # QR Code 1 (Permanent 4G / Partout) -> pointe vers le canal fixe https://ntfy.sh/asd-durlinsdorf-admin-1969
    qr_permanent_4g_b64 = _make_print_qr(ntfy_url)
    # QR Code 2 (Permanent Wi-Fi Club-House) -> pointe vers http://<NOM_HOTE>.local:5000/admin
    qr_permanent_wifi_b64 = _make_print_qr(mdns_admin_url)

    # Intégration du vrai blason (static/logo_asd.png) en Base64 pour fonctionnement 100 % hors-ligne
    if not os.path.exists(CLUB_LOGO_PATH):
        try:
            FFFScraper().fetch_and_save_club_logo(force=False)
        except Exception:
            pass

    logo_b64 = ""
    if os.path.exists(CLUB_LOGO_PATH):
        try:
            with open(CLUB_LOGO_PATH, "rb") as lf:
                raw_logo = lf.read()
                mime = "image/svg+xml" if raw_logo.lstrip().startswith(b"<") else "image/png"
                logo_b64 = f"data:{mime};base64,{base64.b64encode(raw_logo).decode('ascii')}"
        except Exception:
            logo_b64 = ""

    logo_img_html = (
        f'<img src="{logo_b64}" alt="Blason AS Durlinsdorf" class="logo" />'
        if logo_b64
        else '<div class="logo-fallback">ASD 1969</div>'
    )

    generated_date = datetime.datetime.now().strftime("%d/%m/%Y à %H:%M")
    remote_display_url = (
        remote_admin_url
        if remote_admin_url
        else "Publié automatiquement en direct sur le canal ntfy.sh ci-dessus"
    )

    html_content = f"""<!DOCTYPE html>
<html lang="fr" translate="no" class="notranslate">
<head>
  <meta charset="UTF-8" />
  <meta name="google" content="notranslate" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>AS DURLINSDORF - Accès Administration Affichage TV (QR Permanents)</title>
  <style>
    @page {{
      size: A4 portrait;
      margin: 10mm;
    }}
    * {{
      box-sizing: border-box;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }}
    body {{
      margin: 0;
      padding: 20px;
      background-color: #0B0F17;
      color: #FFFFFF;
      font-family: 'Segoe UI', system-ui, -apple-system, Roboto, Arial, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
    }}
    .toolbar {{
      width: 100%;
      max-width: 780px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
      gap: 12px;
    }}
    .btn-print {{
      background-color: #FFD700;
      color: #0B0F17;
      border: none;
      border-radius: 12px;
      padding: 12px 24px;
      font-size: 15px;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 1px;
      cursor: pointer;
      box-shadow: 0 8px 20px rgba(255, 215, 0, 0.35);
    }}
    .btn-back {{
      color: #FFD700;
      text-decoration: none;
      font-weight: 700;
      font-size: 14px;
      border: 1px solid rgba(255, 215, 0, 0.4);
      padding: 10px 18px;
      border-radius: 10px;
    }}
    .sheet {{
      width: 100%;
      max-width: 780px;
      background: linear-gradient(180deg, #111827 0%, #0B0F17 100%);
      border: 4px solid #FFD700;
      border-radius: 26px;
      padding: 26px 28px;
      text-align: center;
      box-shadow: 0 20px 50px rgba(0, 0, 0, 0.75);
    }}
    .header-badge {{
      display: inline-block;
      background-color: #FFD700;
      color: #0B0F17;
      font-weight: 900;
      font-size: 12px;
      padding: 5px 16px;
      border-radius: 999px;
      letter-spacing: 2px;
      text-transform: uppercase;
      margin-bottom: 10px;
    }}
    .logo {{
      width: 82px;
      height: 82px;
      object-fit: contain;
      display: block;
      margin: 0 auto 8px auto;
    }}
    h1 {{
      margin: 0;
      font-size: 24px;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: #FFFFFF;
    }}
    .subtitle {{
      margin-top: 4px;
      font-size: 13px;
      font-weight: 800;
      color: #FFD700;
      text-transform: uppercase;
      letter-spacing: 1.2px;
    }}
    .pin-banner {{
      display: inline-flex;
      align-items: center;
      gap: 14px;
      background-color: #FFD700;
      color: #0B0F17;
      padding: 8px 24px;
      border-radius: 14px;
      margin: 14px 0;
    }}
    .pin-label {{
      font-size: 13px;
      font-weight: 900;
      text-transform: uppercase;
    }}
    .pin-code {{
      font-size: 24px;
      font-weight: 900;
      letter-spacing: 5px;
      font-family: Consolas, Monaco, monospace;
    }}
    .grid-2 {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 18px;
      margin-top: 10px;
      text-align: center;
    }}
    .card {{
      background-color: #0B0F17;
      border: 2px solid #10B981;
      border-radius: 20px;
      padding: 18px 16px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: space-between;
    }}
    .card-local {{
      border-color: #FFD700;
    }}
    .card-badge {{
      display: inline-block;
      padding: 5px 14px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 0.8px;
      margin-bottom: 8px;
    }}
    .badge-4g {{
      background-color: #10B981;
      color: #0B0F17;
    }}
    .badge-wifi {{
      background-color: #FFD700;
      color: #0B0F17;
    }}
    .qr-box {{
      background-color: #FFFFFF;
      border: 4px solid #FFD700;
      border-radius: 18px;
      padding: 10px;
      width: 205px;
      height: 205px;
      margin: 10px auto;
      display: flex;
      align-items: center;
      justify-content: center;
    }}
    .qr-box-4g {{
      border-color: #10B981;
    }}
    .qr-box img {{
      width: 100%;
      height: 100%;
      object-fit: contain;
    }}
    .url-label {{
      font-size: 11px;
      font-weight: 800;
      text-transform: uppercase;
      color: #94A3B8;
      margin-top: 6px;
    }}
    .url-val {{
      font-family: Consolas, Monaco, monospace;
      font-size: 13px;
      font-weight: 900;
      color: #FFD700;
      word-break: break-all;
      margin-top: 3px;
    }}
    .url-val-green {{
      color: #34D399;
    }}
    .sub-box {{
      margin-top: 8px;
      background-color: rgba(255, 255, 255, 0.04);
      border: 1px solid rgba(255, 255, 255, 0.12);
      border-radius: 10px;
      padding: 6px 10px;
      width: 100%;
    }}
    .info-bar {{
      margin-top: 16px;
      background-color: rgba(255, 215, 0, 0.08);
      border: 2px solid rgba(255, 215, 0, 0.45);
      border-radius: 16px;
      padding: 12px 16px;
      text-align: left;
      font-size: 12px;
      color: #E2E8F0;
      line-height: 1.45;
    }}
    .footer-note {{
      margin-top: 12px;
      font-size: 11px;
      color: #64748B;
      text-transform: uppercase;
      letter-spacing: 1px;
    }}
    @media print {{
      body {{
        background-color: #FFFFFF;
        padding: 0;
      }}
      .no-print {{
        display: none !important;
      }}
      .sheet {{
        box-shadow: none;
        max-width: 100%;
      }}
    }}
  </style>
</head>
<body>
  <div class="toolbar no-print">
    <a href="/admin" class="btn-back">← Retour à l'Administration</a>
    <div style="display: flex; gap: 10px;">
      <a href="/portail?download=1" class="btn-back" style="border-color: #10B981; color: #34D399;">⚡ Télécharger Portail Auto-Redirect (.html)</a>
      <button type="button" onclick="window.print()" class="btn-print">🖨️ Imprimer cette fiche (100% Permanente)</button>
    </div>
  </div>

  <div class="sheet">
    <div class="header-badge">CLUB-HOUSE • DEPUIS 1969 • FICHE PERMANENTE (NE PÉRIME JAMAIS)</div>
    {logo_img_html}
    <h1>AS DURLINSDORF - Accès Administration Affichage TV</h1>
    <div class="subtitle">2 QR Codes 100% Permanents : En 4G partout ou sur le Wi-Fi du Club-House</div>

    <div class="pin-banner">
      <span class="pin-label">🔐 Code PIN Administration :</span>
      <span class="pin-code">{pin}</span>
    </div>

    <div class="grid-2">
      <!-- COLONNE 1 : QR CODE 100% PERMANENT 4G / PARTOUT (NTFY.SH) -->
      <div class="card">
        <div>
          <span class="card-badge badge-4g">🌐 Accès 4G / Partout (Permanent)</span>
          <div style="font-size: 12px; color: #E2E8F0; font-weight: 700;">
            Ouvre le canal permanent où s'affiche toujours le dernier lien 4G actif (même après coupure électrique)
          </div>
        </div>
        <div class="qr-box qr-box-4g">
          <img src="{qr_permanent_4g_b64}" alt="QR Code Permanent 4G ntfy.sh" />
        </div>
        <div style="width: 100%;">
          <div class="url-label">Canal Fixe Permanent (ne change jamais)</div>
          <div class="url-val url-val-green">{ntfy_url}</div>
          <div class="sub-box">
            <div class="url-label" style="margin-top: 0;">Dernier lien direct 4G connu :</div>
            <div class="url-val" style="font-size: 11px;">{remote_display_url}</div>
          </div>
        </div>
      </div>

      <!-- COLONNE 2 : QR CODE 100% PERMANENT WI-FI CLUB-HOUSE (.LOCAL + IP) -->
      <div class="card card-local">
        <div>
          <span class="card-badge badge-wifi">📶 Accès Wi-Fi Club-House</span>
          <div style="font-size: 12px; color: #E2E8F0; font-weight: 700;">
            Fonctionne toujours sur le Wi-Fi du Club-House (même si Internet est coupé)
          </div>
        </div>
        <div class="qr-box">
          <img src="{qr_permanent_wifi_b64}" alt="QR Code Permanent Wi-Fi Club-House" />
        </div>
        <div style="width: 100%;">
          <div class="url-label">Adresse Hôte Permanente Wi-Fi</div>
          <div class="url-val">{mdns_admin_url}</div>
          <div class="sub-box">
            <div class="url-label" style="margin-top: 0;">Adresse IP Locale actuelle :</div>
            <div class="url-val" style="font-size: 12px;">{admin_url}</div>
          </div>
        </div>
      </div>
    </div>

    <!-- ASTUCE DE SECOURS SUR L'ÉCRAN TV -->
    <div class="info-bar">
      <strong style="color: #FFD700;">💡 Astuce sans clavier ni souris :</strong>
      À chaque allumage électrique du Raspberry Pi et si le tunnel devait un jour redémarrer avec une nouvelle adresse, le QR Code d'accès direct se ré-affiche automatiquement sur la TV pendant <strong>45 secondes</strong> !
      <br />
      <span style="color: #34D399; font-weight: 700;">⚡ Portail de Redirection Automatique :</span> Le fichier <code>portail_admin_permanent.html</code> interroge <code>https://ntfy.sh/{TUNNEL_JSON_NTFY_TOPIC}</code> et redirige instantanément votre smartphone vers le dernier lien actif.
    </div>

    <div class="footer-note">
      AS Durlinsdorf (Affiliation FFF #523732) • Tunnel Keep-Alive 24h/24 &amp; Anti-Bruteforce Actifs • Généré le {generated_date}
    </div>
  </div>
</body>
</html>
"""
    try:
        with open(PRINTABLE_QR_PATH, "w", encoding="utf-8") as f:
            f.write(html_content)
    except Exception as exc:
        logger.error("Impossible d'écrire qr_code_imprimable.html : %s", exc)

    return html_content


def load_db() -> Dict[str, Any]:
    """Charge la base de données locale de manière thread-safe."""
    with db_lock:
        if not os.path.exists(DB_PATH):
            return {"settings": {"admin_pin": "1969", "display_mode": "competitions"}, "teams": []}
        try:
            with open(DB_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as exc:
            logger.error("Erreur lecture database.json : %s", exc)
            return {"settings": {"admin_pin": "1969", "display_mode": "competitions"}, "teams": []}


def save_db(data: Dict[str, Any], broadcast: bool = True) -> None:
    """Sauvegarde atomique de `database.json` et notification SSE temps réel."""
    global state_version
    with db_lock:
        tmp_path = f"{DB_PATH}.tmp.{os.getpid()}.{threading.get_ident()}"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, DB_PATH)
        finally:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
        state_version = int(time.time() * 1000)

    if broadcast:
        notify_sse_clients()


def notify_sse_clients() -> None:
    """Notifie tous les écrans TV connectés en Server-Sent Events (SSE)."""
    payload = get_public_state()
    msg = f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"
    with sse_lock:
        stale: List[queue.Queue] = []
        for q in sse_clients:
            try:
                q.put_nowait(msg)
            except queue.Full:
                stale.append(q)
        for q in stale:
            if q in sse_clients:
                sse_clients.remove(q)


def get_club_logo_url() -> str:
    """Retourne l'URL locale du logo du club avec un paramètre de version anti-cache."""
    if os.path.exists(CLUB_LOGO_PATH):
        mtime = int(os.path.getmtime(CLUB_LOGO_PATH))
        return f"/static/logo_asd.png?v={mtime}"
    return "/static/logo_asd.png"


def get_public_state() -> Dict[str, Any]:
    """Construit l'état complet (sans le code PIN ni les tokens secrets) envoyé à la TV et aux clients."""
    db = copy.deepcopy(load_db())
    settings = db.get("settings", {})
    topic = get_ntfy_topic(db)

    has_cf_token = bool(str(settings.get("cloudflare_tunnel_token") or "").strip())
    has_ngrok_token = bool(str(settings.get("ngrok_authtoken") or "").strip())

    # Masque les secrets dans l'état public
    settings.pop("admin_pin", None)
    settings.pop("cloudflare_tunnel_token", None)
    settings.pop("ngrok_authtoken", None)
    settings["ntfy_topic"] = topic
    settings["has_cloudflare_token"] = has_cf_token
    settings["has_ngrok_token"] = has_ngrok_token

    admin_url = get_admin_url()
    mdns_admin_url = get_mdns_admin_url()
    ntfy_url = f"https://ntfy.sh/{topic}"

    tunnel_info: Dict[str, Any] = {
        "status": "starting",
        "public_base_url": "",
        "public_admin_url": "",
        "ntfy_topic": topic,
        "ntfy_url": ntfy_url,
    }
    if "tunnel_manager" in globals():
        tunnel_info = tunnel_manager.get_info(ntfy_topic=topic)

    remote_admin_url = str(tunnel_info.get("public_admin_url") or "")
    tunnel_info["qr_remote_b64"] = (
        generate_qr_base64(
            remote_admin_url,
            fill_color="#0B0F17",
            back_color="#FFD700",
        )
        if remote_admin_url
        else ""
    )
    tunnel_info["qr_ntfy_b64"] = generate_qr_base64(
        ntfy_url,
        fill_color="#0B0F17",
        back_color="#FFFFFF",
    )

    return {
        "version": state_version,
        "server_time": datetime.datetime.now().isoformat(),
        "local_ip": get_local_ip(),
        "hostname_local": get_hostname_local(),
        "admin_url": admin_url,
        "mdns_admin_url": mdns_admin_url,
        "club_logo_url": get_club_logo_url(),
        "qr_code_b64": generate_qr_base64(admin_url),
        "qr_mdns_b64": generate_qr_base64(mdns_admin_url),
        "qr_overlay": copy.deepcopy(qr_overlay_state),
        "tv_reload_id": tv_reload_id,
        "remote_tunnel": tunnel_info,
        "settings": settings,
        "featured_event": db.get("featured_event", {}),
        "ticker_messages": db.get("ticker_messages", []),
        "sponsors": db.get("sponsors", []),
        "buvette_categories": db.get("buvette_categories", []),
        "buvette_items": db.get("buvette_items", []),
        "teams": db.get("teams", []),
    }


def wmo_code_to_french(code: int, is_day: int = 1) -> Dict[str, str]:
    """Traduit les codes météo WMO d'Open-Meteo en libellés et clés d'icônes SVG vectorielles (sans emoji Unicode)."""
    mapping = {
        0: ("Ciel dégagé", "sun" if is_day else "moon"),
        1: ("Peu nuageux", "partly_cloudy" if is_day else "moon"),
        2: ("Partiellement voilé", "partly_cloudy"),
        3: ("Couvert", "cloudy"),
        45: ("Brouillard", "fog"),
        48: ("Brouillard givrant", "fog"),
        51: ("Bruine légère", "drizzle"),
        53: ("Bruine modérée", "drizzle"),
        55: ("Bruine dense", "rain"),
        61: ("Pluie faible", "drizzle"),
        63: ("Pluie modérée", "rain"),
        65: ("Pluie forte", "heavy_rain"),
        71: ("Neige faible", "snow"),
        73: ("Neige modérée", "snow"),
        75: ("Chutes de neige", "snow"),
        80: ("Averses légères", "drizzle"),
        81: ("Averses modérées", "rain"),
        82: ("Fortes averses", "heavy_rain"),
        95: ("Orage", "thunder"),
        96: ("Orage et grêle", "thunder"),
        99: ("Orage violent", "thunder"),
    }
    desc, icon_key = mapping.get(code, ("Variable", "partly_cloudy"))
    return {"description": desc, "icon": icon_key, "icon_key": icon_key}


def fetch_durlinsdorf_weather() -> Dict[str, Any]:
    """Récupère la météo en direct à Durlinsdorf (47.486, 7.241) via Open-Meteo (sans clé)."""
    now = time.time()
    if now - weather_cache["timestamp"] < 900:  # Cache de 15 minutes
        return weather_cache["data"]

    db = load_db()
    settings = db.get("settings", {})
    lat = settings.get("weather_lat", 47.486)
    lon = settings.get("weather_lon", 7.241)

    url = (
        f"https://api.open-meteo.com/v1/forecast"
        f"?latitude={lat}&longitude={lon}"
        f"&current=temperature_2m,weather_code,wind_speed_10m,is_day"
        f"&timezone=Europe%2FParis"
    )
    try:
        resp = requests.get(url, timeout=5)
        if resp.status_code == 200:
            payload = resp.json()
            curr = payload.get("current", {})
            temp = round(float(curr.get("temperature_2m", 14.0)))
            code = int(curr.get("weather_code", 1))
            wind = round(float(curr.get("wind_speed_10m", 5.0)))
            is_day = int(curr.get("is_day", 1))
            wmo = wmo_code_to_french(code, is_day)

            weather_cache["data"] = {
                "temp": temp,
                "weather_code": code,
                "description": wmo["description"],
                "icon": wmo["icon_key"],
                "icon_key": wmo["icon_key"],
                "wind_kmh": wind,
                "city": "Durlinsdorf",
                "updated_at": datetime.datetime.now().strftime("%H:%M"),
            }
            weather_cache["timestamp"] = now
    except Exception as exc:
        logger.debug("Météo Open-Meteo hors-ligne (utilisation du cache) : %s", exc)

    return weather_cache["data"]


# =============================================================================
# AUTHENTIFICATION PAR CODE PIN (DÉFAUT : 1969) + PROTECTION ANTI-BRUTEFORCE
# =============================================================================
def get_configured_pin() -> str:
    db = load_db()
    return str(db.get("settings", {}).get("admin_pin", "1969")).strip()


def get_client_ip() -> str:
    """
    Récupère l'adresse IP réelle du client (compatible avec Cloudflare Tunnel `CF-Connecting-IP`
    et les proxys `X-Forwarded-For` pour isoler chaque appareil 4G/5G).
    """
    cf_ip = request.headers.get("CF-Connecting-IP", "").strip()
    if cf_ip:
        return cf_ip
    xff = request.headers.get("X-Forwarded-For", "").strip()
    if xff:
        return xff.split(",")[0].strip()
    return request.remote_addr or "unknown"


def get_ip_lockout_remaining(ip: str) -> int:
    """Retourne le nombre de secondes restantes de blocage Anti-Bruteforce (0 si non bloqué)."""
    now = time.time()
    with pin_bruteforce_lock:
        rec = pin_attempts_by_ip.get(ip)
        if not rec:
            return 0
        locked_until = float(rec.get("locked_until", 0.0))
        if locked_until > now:
            return int(locked_until - now) + 1
        if locked_until > 0 and locked_until <= now:
            # Expiration de la pénalité de 10 minutes : remise à zéro du compteur
            pin_attempts_by_ip.pop(ip, None)
        return 0


def register_failed_pin_attempt(ip: str) -> tuple[int, int]:
    """
    Enregistre un échec de code PIN pour cette IP.
    Au bout de 5 tentatives erronées, bloque l'adresse IP pendant 10 minutes (600 secondes).
    """
    now = time.time()
    with pin_bruteforce_lock:
        rec = pin_attempts_by_ip.setdefault(ip, {"fails": 0, "locked_until": 0.0})
        if rec["locked_until"] > 0 and rec["locked_until"] <= now:
            rec["fails"] = 0
            rec["locked_until"] = 0.0
        rec["fails"] = int(rec["fails"]) + 1
        fails = rec["fails"]
        if fails >= MAX_PIN_ATTEMPTS:
            rec["locked_until"] = now + PIN_LOCKOUT_SECONDS
            logger.warning(
                "ALERTE SÉCURITÉ : IP %s bloquée pour 10 minutes après %d codes PIN erronés.",
                ip,
                fails,
            )
            return fails, PIN_LOCKOUT_SECONDS
        return fails, 0


def clear_pin_attempts(ip: str) -> None:
    """Réinitialise le compteur d'échecs de cette IP après un code PIN valide."""
    with pin_bruteforce_lock:
        pin_attempts_by_ip.pop(ip, None)


def is_admin_authenticated() -> bool:
    ip = get_client_ip()
    if get_ip_lockout_remaining(ip) > 0:
        return False
    if session.get("admin_authenticated") is True:
        return True
    header_pin = request.headers.get("X-Admin-Pin", "").strip()
    if header_pin:
        if header_pin == get_configured_pin():
            clear_pin_attempts(ip)
            return True
        register_failed_pin_attempt(ip)
    return False


def admin_required(f: Callable) -> Callable:
    @wraps(f)
    def decorated(*args: Any, **kwargs: Any) -> Any:
        ip = get_client_ip()
        rem = get_ip_lockout_remaining(ip)
        if rem > 0:
            mins = max(1, (rem + 59) // 60)
            return jsonify({
                "ok": False,
                "error": f"Trop de tentatives. Accès bloqué pendant {mins} min ({rem}s).",
                "locked": True,
                "retry_after_seconds": rem,
                "auth_required": True,
            }), 429
        if not is_admin_authenticated():
            return jsonify({"ok": False, "error": "Code PIN requis ou invalide", "auth_required": True}), 401
        return f(*args, **kwargs)

    return decorated


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.after_request
def add_no_cache_headers(response: Response) -> Response:
    """Empêche le navigateur / smartphone de garder en cache une ancienne version de /admin ou /tv."""
    if request.path in ("/", "/tv", "/admin", "/admin/print-qr") or request.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


# =============================================================================
# ROUTES VUES HTML (/tv, /, /admin)
# =============================================================================
@app.route("/")
def index() -> Response:
    """Redirige la racine vers l'écran TV principal."""
    return redirect(url_for("tv_view"))


@app.route("/tv")
def tv_view() -> str:
    """Vue principale TV 1080p Zero-Scroll."""
    initial_state = get_public_state()
    initial_weather = fetch_durlinsdorf_weather()
    return render_template(
        "tv.html",
        initial_state=initial_state,
        initial_weather=initial_weather,
    )


@app.route("/admin")
def admin_view() -> str:
    """Interface Mobile-First d'Administration par Smartphone."""
    initial_state = get_public_state()
    return render_template(
        "admin.html",
        initial_state=initial_state,
        authenticated=is_admin_authenticated(),
    )


# =============================================================================
# ENDPOINTS PUBLICS TEMPS RÉEL (TV, SSE, MÉTÉO, QR CODE)
# =============================================================================
@app.route("/api/state")
def api_state() -> Response:
    """Retourne l'état complet courant pour le polling rapide de la TV et l'Admin."""
    return jsonify(get_public_state())


@app.route("/api/stream")
def api_stream() -> Response:
    """Flux Server-Sent Events (SSE) pour bascule instantanée des modes sur la TV."""
    def event_stream() -> Any:
        q: queue.Queue = queue.Queue(maxsize=25)
        with sse_lock:
            sse_clients.append(q)
        try:
            # Envoi immédiat de l'état initial à la connexion
            init_payload = get_public_state()
            yield f"data: {json.dumps(init_payload, ensure_ascii=False)}\n\n"
            while True:
                try:
                    msg = q.get(timeout=20)
                    yield msg
                except queue.Empty:
                    # Heartbeat régulier pour maintenir la connexion active sur Chromium RPi
                    yield f": heartbeat {int(time.time())}\n\n"
        finally:
            with sse_lock:
                if q in sse_clients:
                    sse_clients.remove(q)

    headers = {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "X-Accel-Buffering": "no",
        "Connection": "keep-alive",
    }
    return Response(event_stream(), headers=headers)


@app.route("/api/weather")
def api_weather() -> Response:
    """Retourne la météo locale de Durlinsdorf (avec cache hors-ligne)."""
    return jsonify(fetch_durlinsdorf_weather())


@app.route("/admin/print-qr")
def admin_print_qr() -> Response:
    """Génère et affiche la fiche A4/A5 prête à imprimer (`qr_code_imprimable.html`)."""
    html_doc = generate_printable_qr_html(admin_url=get_admin_url(), pin=get_configured_pin())
    return Response(html_doc, mimetype="text/html; charset=utf-8")


@app.route("/portail")
@app.route("/admin/portail-permanent")
def admin_portail_permanent() -> Response:
    """
    Sert ou télécharge la page autonome `portail_admin_permanent.html` qui interroge
    `https://ntfy.sh/asd-durlinsdorf-tunnel-1969/json?poll=1` et redirige automatiquement
    le smartphone (`window.location.replace(...)`) vers la dernière URL Cloudflare active.
    """
    as_attachment = request.args.get("download") in ("1", "true", "yes")
    if os.path.exists(PORTAIL_PERMANENT_PATH):
        return send_file(
            PORTAIL_PERMANENT_PATH,
            mimetype="text/html; charset=utf-8",
            as_attachment=as_attachment,
            download_name="portail_admin_permanent.html",
        )
    return redirect(url_for("admin_view"))


@app.route("/api/qrcode.png")
def api_qrcode_png() -> Response:
    """
    Génère dynamiquement l'image PNG du QR Code :
    - `?target=remote` : URL publique 4G/Internet (`https://xxxx.trycloudflare.com/admin`)
    - `?target=ntfy`   : Canal fixe permanent (`https://ntfy.sh/asd-durlinsdorf-admin-...`)
    - `?target=local`  : URL Wi-Fi locale (`http://192.168.x.x:5000/admin`)
    """
    target = str(request.args.get("target") or "remote").lower()
    topic = get_ntfy_topic()
    ntfy_url = f"https://ntfy.sh/{topic}"
    local_url = get_admin_url()
    remote_url = ""
    if "tunnel_manager" in globals():
        remote_url = str(tunnel_manager.get_info(ntfy_topic=topic).get("public_admin_url") or "")

    if target == "local":
        qr_target_url = local_url
        filename = "qrcode_wifi_local_as_durlinsdorf.png"
    elif target == "ntfy":
        qr_target_url = ntfy_url
        filename = "qrcode_permanent_ntfy_as_durlinsdorf.png"
    else:
        qr_target_url = remote_url if remote_url else local_url
        filename = "qrcode_4g_internet_as_durlinsdorf.png"

    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=12,
        border=2,
    )
    qr.add_data(qr_target_url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="#0B0F17", back_color="#FFD700")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    as_attachment = request.args.get("download") in ("1", "true", "yes")
    return send_file(
        buf,
        mimetype="image/png",
        as_attachment=as_attachment,
        download_name=filename,
    )


# =============================================================================
# ENDPOINTS D'ADMINISTRATION MOBILE (`/api/admin/...`)
# =============================================================================
@app.route("/api/admin/login", methods=["POST"])
def api_admin_login() -> Any:
    """
    Vérifie le code PIN à 4 chiffres (par défaut 1969) avec protection Anti-Bruteforce
    (5 tentatives erronées par IP -> blocage de 10 minutes).
    """
    ip = get_client_ip()
    rem = get_ip_lockout_remaining(ip)
    if rem > 0:
        mins = max(1, (rem + 59) // 60)
        return jsonify({
            "ok": False,
            "locked": True,
            "retry_after_seconds": rem,
            "error": f"Sécurité : Trop d'essais. Réessayez dans {mins} min ({rem}s).",
        }), 429

    body = request.get_json(silent=True) or {}
    pin = str(body.get("pin", "")).strip()
    if pin == get_configured_pin():
        clear_pin_attempts(ip)
        session["admin_authenticated"] = True
        session.permanent = True
        return jsonify({"ok": True, "message": "Authentification réussie", "state": get_public_state()})

    fails, lockout_sec = register_failed_pin_attempt(ip)
    if lockout_sec > 0:
        return jsonify({
            "ok": False,
            "locked": True,
            "retry_after_seconds": lockout_sec,
            "error": "5 essais erronés : accès bloqué pendant 10 minutes par sécurité.",
        }), 429

    remaining_tries = max(0, MAX_PIN_ATTEMPTS - fails)
    return jsonify({
        "ok": False,
        "remaining_attempts": remaining_tries,
        "error": f"Code PIN incorrect ({remaining_tries} essai{'s' if remaining_tries > 1 else ''} restant{'s' if remaining_tries > 1 else ''})",
    }), 403


@app.route("/api/admin/logout", methods=["POST"])
def api_admin_logout() -> Response:
    """Déconnecte la session d'administration."""
    session.pop("admin_authenticated", None)
    return jsonify({"ok": True})


@app.route("/api/admin/pin", methods=["POST"])
@admin_required
def api_admin_change_pin() -> Any:
    """Modifie le code PIN d'administration."""
    body = request.get_json(silent=True) or {}
    new_pin = str(body.get("new_pin", "")).strip()
    if not (len(new_pin) == 4 and new_pin.isdigit()):
        return jsonify({"ok": False, "error": "Le code PIN doit comporter exactement 4 chiffres."}), 400

    db = load_db()
    db.setdefault("settings", {})["admin_pin"] = new_pin
    save_db(db, broadcast=False)
    generate_printable_qr_html(admin_url=get_admin_url(), pin=new_pin)
    return jsonify({"ok": True, "message": "Code PIN mis à jour avec succès."})


@app.route("/api/admin/mode", methods=["POST"])
@admin_required
def api_admin_mode() -> Any:
    """
    Change instantanément le mode de la TV (`competitions`, `buvette`, `mixed`)
    et/ou les paramètres d'affichage (durées de rotation, affichage QR code, vitesse ticker).
    """
    body = request.get_json(silent=True) or {}
    db = load_db()
    settings = db.setdefault("settings", {})

    if "display_mode" in body:
        mode = str(body["display_mode"]).strip()
        if mode in ("competitions", "buvette", "mixed"):
            settings["display_mode"] = mode

    int_fields = (
        ("team_rotation_seconds", 5, 120),
        ("mixed_competitions_seconds", 15, 600),
        ("mixed_buvette_seconds", 10, 600),
        ("sponsor_rotation_seconds", 3, 60),
        ("ticker_speed_seconds", 10, 120),
    )
    for key, min_v, max_v in int_fields:
        if key in body:
            try:
                val = int(body[key])
                settings[key] = max(min_v, min(max_v, val))
            except (ValueError, TypeError):
                pass

    if "show_qr_code" in body:
        settings["show_qr_code"] = bool(body["show_qr_code"])

    save_db(db, broadcast=True)
    return jsonify({"ok": True, "state": get_public_state()})


# -----------------------------------------------------------------------------
# GESTION DE LA SYNCHRONISATION FFF & DES ÉQUIPES
# -----------------------------------------------------------------------------
def run_fff_sync(force_manual: bool = False) -> Dict[str, Any]:
    """Exécute la synchronisation FFF et sauvegarde les résultats dans `database.json`."""
    global last_fff_sync_epoch
    db = load_db()
    teams = db.get("teams", [])
    report = fff_scraper.sync_all_teams(teams, force_manual=force_manual)

    with db_lock:
        fresh_db = load_db()
        fresh_db["teams"] = report["teams"]
        fresh_db.setdefault("settings", {})["last_fff_sync"] = report["last_sync"]
        fresh_db["settings"]["fff_sync_status"] = report["status"]
        if report.get("cl_no"):
            fresh_db["settings"]["club_cl_no"] = report["cl_no"]
        save_db(fresh_db, broadcast=True)

    last_fff_sync_epoch = time.time()
    return report


@app.route("/api/admin/teams/toggle", methods=["POST"])
@admin_required
def api_admin_toggle_team() -> Any:
    """Active ou désactive instantanément l'affichage d'une équipe du club sur la TV."""
    body = request.get_json(silent=True) or {}
    team_id = str(body.get("id") or "").strip()
    active_val = body.get("active")

    db = load_db()
    for t in db.get("teams", []):
        if t.get("id") == team_id:
            if active_val is None:
                t["active"] = not bool(t.get("active", True))
            else:
                t["active"] = bool(active_val)
            break

    save_db(db, broadcast=True)
    return jsonify({"ok": True, "state": get_public_state()})


@app.route("/api/admin/fff/sync", methods=["POST"])
@admin_required
def api_admin_fff_sync() -> Response:
    """Force la synchronisation immédiate des données FFF."""
    body = request.get_json(silent=True) or {}
    force_manual = bool(body.get("force_manual", False))
    report = run_fff_sync(force_manual=force_manual)
    return jsonify({
        "ok": True,
        "report": report,
        "state": get_public_state(),
    })


@app.route("/api/admin/teams", methods=["POST"])
@admin_required
def api_admin_save_team() -> Any:
    """Crée ou met à jour une équipe FFF (configuration, score manuel, classement)."""
    body = request.get_json(silent=True) or {}
    team_id = str(body.get("id") or "").strip()
    if not team_id:
        team_id = f"team-{uuid.uuid4().hex[:8]}"

    db = load_db()
    teams = db.setdefault("teams", [])

    existing_idx = next((i for i, t in enumerate(teams) if t.get("id") == team_id), None)
    target = copy.deepcopy(teams[existing_idx]) if existing_idx is not None else {
        "id": team_id,
        "name": "Nouvelle Équipe ASD",
        "short_name": "ASD",
        "category": "Seniors",
        "competition": "District Alsace",
        "fff_slug": "",
        "fff_cp_no": "",
        "fff_ph_no": "1",
        "fff_po_no": "",
        "fff_url": "",
        "active": True,
        "manual_override": False,
        "form": ["V", "N", "V"],
        "last_match": {},
        "next_match": {},
        "standings": [],
    }

    for field in (
        "name",
        "short_name",
        "category",
        "competition",
        "fff_slug",
        "fff_cp_no",
        "fff_ph_no",
        "fff_po_no",
        "fff_url",
    ):
        if field in body:
            target[field] = str(body[field] or "").strip()

    if "active" in body:
        target["active"] = bool(body["active"])
    if "manual_override" in body:
        target["manual_override"] = bool(body["manual_override"])

    if "last_match" in body and isinstance(body["last_match"], dict):
        lm = body["last_match"]
        h_score = lm.get("home_score")
        a_score = lm.get("away_score")
        target["last_match"] = {
            "home_team": str(lm.get("home_team") or "AS Durlinsdorf").strip(),
            "away_team": str(lm.get("away_team") or "Adversaire").strip(),
            "home_score": int(h_score) if h_score not in (None, "") else None,
            "away_score": int(a_score) if a_score not in (None, "") else None,
            "opponent": str(lm.get("opponent") or lm.get("away_team") or "Adversaire").strip(),
            "venue": str(lm.get("venue") or "Domicile").strip(),
            "date": str(lm.get("date") or "").strip(),
            "time": str(lm.get("time") or "15:00").strip(),
            "competition": str(lm.get("competition") or target.get("competition") or "").strip(),
            "note": str(lm.get("note") or "").strip(),
        }

    if "next_match" in body and isinstance(body["next_match"], dict):
        nm = body["next_match"]
        target["next_match"] = {
            "home_team": str(nm.get("home_team") or "AS Durlinsdorf").strip(),
            "away_team": str(nm.get("away_team") or "Adversaire").strip(),
            "home_score": None,
            "away_score": None,
            "opponent": str(nm.get("opponent") or nm.get("away_team") or "Adversaire").strip(),
            "venue": str(nm.get("venue") or "Domicile").strip(),
            "date": str(nm.get("date") or "").strip(),
            "time": str(nm.get("time") or "15:00").strip(),
            "competition": str(nm.get("competition") or target.get("competition") or "").strip(),
            "note": str(nm.get("note") or "").strip(),
        }

    if "standings" in body and isinstance(body["standings"], list):
        cleaned_standings = []
        for idx, row in enumerate(body["standings"], start=1):
            if not isinstance(row, dict):
                continue
            club_name = str(row.get("club") or f"Club {idx}").strip()
            cleaned_standings.append({
                "pos": int(row.get("pos", idx) or idx),
                "club": club_name,
                "pts": int(row.get("pts", 0) or 0),
                "played": int(row.get("played", 0) or 0),
                "won": int(row.get("won", 0) or 0),
                "drawn": int(row.get("drawn", 0) or 0),
                "lost": int(row.get("lost", 0) or 0),
                "gf": int(row.get("gf", 0) or 0),
                "ga": int(row.get("ga", 0) or 0),
                "diff": int(row.get("diff", 0) or 0),
                "is_asd": bool(row.get("is_asd")) or is_asd_team_name(club_name),
            })
        cleaned_standings.sort(key=lambda r: r["pos"])
        target["standings"] = cleaned_standings

    if existing_idx is not None:
        teams[existing_idx] = target
    else:
        teams.append(target)

    save_db(db, broadcast=True)
    return jsonify({"ok": True, "team": target, "state": get_public_state()})


@app.route("/api/admin/teams/<team_id>", methods=["DELETE"])
@admin_required
def api_admin_delete_team(team_id: str) -> Response:
    """Supprime une équipe de la configuration."""
    db = load_db()
    db["teams"] = [t for t in db.get("teams", []) if t.get("id") != team_id]
    save_db(db, broadcast=True)
    return jsonify({"ok": True, "state": get_public_state()})


# -----------------------------------------------------------------------------
# GESTION DE LA CARTE DE LA BUVETTE
# -----------------------------------------------------------------------------
@app.route("/api/admin/buvette/item", methods=["POST"])
@admin_required
def api_admin_save_buvette_item() -> Any:
    """Ajoute ou modifie un produit de la buvette."""
    body = request.get_json(silent=True) or {}
    item_id = str(body.get("id") or "").strip() or f"b-{uuid.uuid4().hex[:6]}"
    name = str(body.get("name") or "").strip()
    if not name:
        return jsonify({"ok": False, "error": "Le nom de l'article est obligatoire."}), 400

    category = str(body.get("category") or "Boissons fraîches").strip()
    fmt = str(body.get("format") or "").strip()
    try:
        price = round(float(str(body.get("price", 0)).replace(",", ".")), 2)
    except ValueError:
        price = 0.0

    available = bool(body.get("available", True))
    is_new = bool(body.get("is_new", False))

    db = load_db()
    cats = db.setdefault("buvette_categories", [
        "Boissons fraîches",
        "Bières & Vins",
        "Restauration / Petite faim",
        "Café & Desserts",
    ])
    if category not in cats:
        cats.append(category)

    items = db.setdefault("buvette_items", [])
    existing_idx = next((i for i, x in enumerate(items) if x.get("id") == item_id), None)

    item_obj = {
        "id": item_id,
        "category": category,
        "name": name,
        "format": fmt,
        "price": price,
        "available": available,
        "is_new": is_new,
    }

    if existing_idx is not None:
        items[existing_idx] = item_obj
    else:
        items.append(item_obj)

    save_db(db, broadcast=True)
    return jsonify({"ok": True, "item": item_obj, "state": get_public_state()})


@app.route("/api/admin/buvette/toggle", methods=["POST"])
@admin_required
def api_admin_toggle_buvette_item() -> Any:
    """Bascule rapidement l'état En stock/Rupture ou le badge Nouveau d'un produit."""
    body = request.get_json(silent=True) or {}
    item_id = str(body.get("id") or "").strip()
    field = str(body.get("field") or "available").strip()

    db = load_db()
    items = db.get("buvette_items", [])
    for item in items:
        if item.get("id") == item_id:
            if field in ("available", "is_new"):
                item[field] = not bool(item.get(field, False))
            break

    save_db(db, broadcast=True)
    return jsonify({"ok": True, "state": get_public_state()})


@app.route("/api/admin/buvette/item/<item_id>", methods=["DELETE"])
@admin_required
def api_admin_delete_buvette_item(item_id: str) -> Response:
    """Supprime un produit de la buvette."""
    db = load_db()
    db["buvette_items"] = [x for x in db.get("buvette_items", []) if x.get("id") != item_id]
    save_db(db, broadcast=True)
    return jsonify({"ok": True, "state": get_public_state()})


@app.route("/api/admin/buvette/categories", methods=["POST"])
@admin_required
def api_admin_buvette_categories() -> Any:
    """Met à jour la liste des catégories de la buvette."""
    body = request.get_json(silent=True) or {}
    categories = body.get("categories")
    if isinstance(categories, list) and categories:
        clean_cats = [str(c).strip() for c in categories if str(c).strip()]
        if clean_cats:
            db = load_db()
            db["buvette_categories"] = clean_cats
            save_db(db, broadcast=True)
    return jsonify({"ok": True, "state": get_public_state()})


# -----------------------------------------------------------------------------
# GESTION DU BANDEAU DÉFILANT (TICKER)
# -----------------------------------------------------------------------------
@app.route("/api/admin/ticker", methods=["POST"])
@admin_required
def api_admin_save_ticker() -> Any:
    """Ajoute, modifie ou active/désactive un message du bandeau défilant."""
    body = request.get_json(silent=True) or {}
    db = load_db()

    if "ticker_speed_seconds" in body:
        try:
            speed = max(10, min(120, int(body["ticker_speed_seconds"])))
            db.setdefault("settings", {})["ticker_speed_seconds"] = speed
        except (ValueError, TypeError):
            pass

    if "text" in body or "id" in body:
        msg_id = str(body.get("id") or "").strip() or f"msg-{uuid.uuid4().hex[:6]}"
        messages = db.setdefault("ticker_messages", [])
        existing_idx = next((i for i, m in enumerate(messages) if m.get("id") == msg_id), None)

        if existing_idx is not None:
            if "text" in body and str(body["text"]).strip():
                messages[existing_idx]["text"] = str(body["text"]).strip()
            if "active" in body:
                messages[existing_idx]["active"] = bool(body["active"])
        else:
            text = str(body.get("text") or "").strip()
            if text:
                messages.append({
                    "id": msg_id,
                    "text": text,
                    "active": bool(body.get("active", True)),
                })

    save_db(db, broadcast=True)
    return jsonify({"ok": True, "state": get_public_state()})


@app.route("/api/admin/ticker/<msg_id>", methods=["DELETE"])
@admin_required
def api_admin_delete_ticker(msg_id: str) -> Response:
    """Supprime un message du bandeau défilant."""
    db = load_db()
    db["ticker_messages"] = [m for m in db.get("ticker_messages", []) if m.get("id") != msg_id]
    save_db(db, broadcast=True)
    return jsonify({"ok": True, "state": get_public_state()})


# -----------------------------------------------------------------------------
# GESTION DES SPONSORS (UPLOAD DEPUIS LA GALERIE DU SMARTPHONE)
# -----------------------------------------------------------------------------
@app.route("/api/admin/sponsors", methods=["POST"])
@admin_required
def api_admin_save_sponsor() -> Any:
    """
    Ajoute ou met à jour un sponsor.
    Supporte soit `multipart/form-data` (avec upload d'image depuis le smartphone),
    soit `application/json`.
    """
    db = load_db()
    sponsors = db.setdefault("sponsors", [])

    if request.content_type and "multipart/form-data" in request.content_type:
        sp_id = str(request.form.get("id") or "").strip() or f"sp-{uuid.uuid4().hex[:6]}"
        name = str(request.form.get("name") or "").strip()
        tagline = str(request.form.get("tagline") or "").strip()
        try:
            duration = max(3, min(60, int(request.form.get("duration_seconds", 8))))
        except ValueError:
            duration = 8
        active = str(request.form.get("active", "true")).lower() in ("true", "1", "yes", "on")

        logo_url = str(request.form.get("logo_url") or "").strip()
        file = request.files.get("logo_file")
        if file and file.filename and allowed_file(file.filename):
            ext = file.filename.rsplit(".", 1)[1].lower()
            safe_name = secure_filename(f"sponsor_{sp_id}_{int(time.time())}.{ext}")
            save_path = os.path.join(UPLOAD_SPONSORS_DIR, safe_name)
            file.save(save_path)
            logo_url = f"/static/uploads/sponsors/{safe_name}"
    else:
        body = request.get_json(silent=True) or {}
        sp_id = str(body.get("id") or "").strip() or f"sp-{uuid.uuid4().hex[:6]}"
        name = str(body.get("name") or "").strip()
        tagline = str(body.get("tagline") or "").strip()
        try:
            duration = max(3, min(60, int(body.get("duration_seconds", 8))))
        except ValueError:
            duration = 8
        active = bool(body.get("active", True))
        logo_url = str(body.get("logo_url") or "").strip()

    existing_idx = next((i for i, s in enumerate(sponsors) if s.get("id") == sp_id), None)
    if existing_idx is not None:
        current = sponsors[existing_idx]
        if name:
            current["name"] = name
        if tagline or "tagline" in (request.form if request.form else (request.get_json(silent=True) or {})):
            current["tagline"] = tagline
        if logo_url:
            current["logo_url"] = logo_url
        current["duration_seconds"] = duration
        current["active"] = active
    else:
        if not name:
            return jsonify({"ok": False, "error": "Le nom du sponsor est requis."}), 400
        sponsors.append({
            "id": sp_id,
            "name": name,
            "tagline": tagline or "Partenaire Officiel AS Durlinsdorf",
            "logo_url": logo_url or "/static/logo_asd.png",
            "duration_seconds": duration,
            "active": active,
        })

    save_db(db, broadcast=True)
    return jsonify({"ok": True, "state": get_public_state()})


@app.route("/api/admin/sponsors/<sp_id>", methods=["DELETE"])
@admin_required
def api_admin_delete_sponsor(sp_id: str) -> Response:
    """Supprime un sponsor."""
    db = load_db()
    db["sponsors"] = [s for s in db.get("sponsors", []) if s.get("id") != sp_id]
    save_db(db, broadcast=True)
    return jsonify({"ok": True, "state": get_public_state()})


# -----------------------------------------------------------------------------
# GESTION DE L'ENCART "ÉVÉNEMENT À LA UNE"
# -----------------------------------------------------------------------------
@app.route("/api/admin/event", methods=["POST"])
@admin_required
def api_admin_save_event() -> Response:
    """Met à jour l'encart 'Événement à la une' (texte + affiche optionnelle depuis smartphone)."""
    db = load_db()
    ev = db.setdefault("featured_event", {})

    if request.content_type and "multipart/form-data" in request.content_type:
        for field in ("badge", "title", "subtitle", "description", "highlight_price"):
            if field in request.form:
                ev[field] = str(request.form.get(field) or "").strip()
        if "enabled" in request.form:
            ev["enabled"] = str(request.form.get("enabled")).lower() in ("true", "1", "yes", "on")

        file = request.files.get("image_file")
        if file and file.filename and allowed_file(file.filename):
            ext = file.filename.rsplit(".", 1)[1].lower()
            safe_name = secure_filename(f"event_{int(time.time())}.{ext}")
            save_path = os.path.join(UPLOAD_EVENTS_DIR, safe_name)
            file.save(save_path)
            ev["image_url"] = f"/static/uploads/events/{safe_name}"
    else:
        body = request.get_json(silent=True) or {}
        for field in ("badge", "title", "subtitle", "description", "highlight_price", "image_url"):
            if field in body:
                ev[field] = str(body[field] or "").strip()
        if "enabled" in body:
            ev["enabled"] = bool(body["enabled"])

    save_db(db, broadcast=True)
    return jsonify({"ok": True, "state": get_public_state()})


# -----------------------------------------------------------------------------
# GESTION DU LOGO OFFICIEL DU CLUB (UPLOAD PERSONNALISÉ OU SYNCHRO FFF)
# -----------------------------------------------------------------------------
@app.route("/api/admin/logo", methods=["POST"])
@admin_required
def api_admin_upload_logo() -> Any:
    """
    Permet d'importer un fichier logo (.png, .jpg, .svg, .webp) depuis le PC ou le smartphone
    et écrase `static/logo_asd.png` avec rafraîchissement instantané sur la TV et l'Admin.
    """
    global state_version
    file = request.files.get("logo_file")
    if not file or not file.filename:
        return jsonify({"ok": False, "error": "Aucun fichier image sélectionné."}), 400
    if not allowed_file(file.filename):
        return jsonify({"ok": False, "error": "Format non supporté (utilisez PNG, JPG, SVG ou WEBP)."}), 400

    ext = file.filename.rsplit(".", 1)[1].lower()
    raw_bytes = file.read()
    if not raw_bytes:
        return jsonify({"ok": False, "error": "Le fichier envoyé est vide."}), 400

    os.makedirs(os.path.dirname(CLUB_LOGO_PATH), exist_ok=True)

    # Conversion propre en PNG si l'image est matricielle (PNG, JPG, WEBP, GIF) et que Pillow est installé
    saved = False
    if ext != "svg":
        try:
            from PIL import Image
            img = Image.open(io.BytesIO(raw_bytes)).convert("RGBA")
            img.save(CLUB_LOGO_PATH, format="PNG")
            saved = True
        except Exception as exc:
            logger.warning("Sauvegarde directe du logo sans conversion Pillow : %s", exc)

    if not saved:
        with open(CLUB_LOGO_PATH, "wb") as f:
            f.write(raw_bytes)

    state_version = int(time.time() * 1000)
    try:
        generate_printable_qr_html(admin_url=get_admin_url(), pin=get_configured_pin())
    except Exception as exc:
        logger.warning("Erreur régénération qr_code_imprimable.html après changement de logo : %s", exc)

    notify_sse_clients()
    return jsonify({
        "ok": True,
        "club_logo_url": get_club_logo_url(),
        "state": get_public_state(),
    })


@app.route("/api/admin/logo/fff", methods=["POST"])
@admin_required
def api_admin_restore_fff_logo() -> Any:
    """Retélécharge le blason officiel depuis l'API FFF (`https://api-dofa.fff.fr/api/clubs/9029`)."""
    global state_version
    scraper = FFFScraper()
    cl_no = scraper.find_club_cl_no()
    path = scraper.fetch_and_save_club_logo(cl_no=cl_no, dest_path=CLUB_LOGO_PATH, force=True)
    if not path:
        return jsonify({"ok": False, "error": "Impossible de récupérer le blason sur l'API FFF."}), 500

    state_version = int(time.time() * 1000)
    try:
        generate_printable_qr_html(admin_url=get_admin_url(), pin=get_configured_pin())
    except Exception:
        pass
    notify_sse_clients()
    return jsonify({
        "ok": True,
        "club_logo_url": get_club_logo_url(),
        "state": get_public_state(),
    })


@app.route("/api/admin/reload-tv", methods=["POST"])
@admin_required
def api_admin_reload_tv() -> Any:
    """Ordonne à tous les écrans `/tv` connectés d'exécuter un `window.location.reload()` à distance."""
    global state_version, tv_reload_id
    tv_reload_id += 1
    state_version = int(time.time() * 1000)
    notify_sse_clients()
    return jsonify({"ok": True, "tv_reload_id": tv_reload_id, "state": get_public_state()})


@app.route("/api/admin/pull-update", methods=["POST"])
@admin_required
def api_admin_pull_update() -> Any:
    """
    Télécharge et applique à distance la dernière archive `asd-dashboard.tar.gz` depuis le PC
    puis relance le serveur et l'écran Kiosk Chromium sans clavier ni souris.
    """
    import subprocess
    import tarfile

    body = request.get_json(silent=True) or {}
    pc_url = str(body.get("pc_url") or "http://192.168.1.29:8080").rstrip("/")
    tar_url = f"{pc_url}/asd-dashboard.tar.gz"
    try:
        resp = requests.get(tar_url, timeout=10)
        if resp.status_code != 200:
            return jsonify({"ok": False, "error": f"HTTP {resp.status_code} sur {tar_url}"}), 502
        with tarfile.open(fileobj=io.BytesIO(resp.content), mode="r:gz") as tar:
            tar.extractall(BASE_DIR)

        kiosk_sh = os.path.join(BASE_DIR, "start_kiosk.sh")
        if os.path.exists(kiosk_sh) and os.name != "nt":
            os.chmod(kiosk_sh, 0o755)
            subprocess.Popen(
                ["bash", "-c", f"sleep 1 && nohup '{kiosk_sh}' >/dev/null 2>&1 &"],
                cwd=BASE_DIR,
            )

        global state_version, tv_reload_id
        tv_reload_id += 1
        state_version = int(time.time() * 1000)
        notify_sse_clients()
        return jsonify({"ok": True, "message": "Mise à jour extraite et Kiosk relancé."})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


# -----------------------------------------------------------------------------
# GESTION DE L'ACCÈS DISTANT 4G / INTERNET (CLOUDFLARE TUNNEL & CANAL NTFY.SH)
# -----------------------------------------------------------------------------
@app.route("/api/admin/remote-config", methods=["POST"])
@admin_required
def api_admin_remote_config() -> Any:
    """
    Met à jour la configuration d'accès distant :
    - `ntfy_topic` : canal permanent ntfy.sh (sans inscription)
    - `cloudflare_tunnel_token` : token optionnel Cloudflare Tunnel nommé
    - `ngrok_authtoken` : token optionnel Ngrok
    - `custom_remote_domain` : sous-domaine fixe personnalisé optionnel (ex: https://asd.mondomaine.fr)
    """
    body = request.get_json(silent=True) or {}
    db = load_db()
    settings = db.setdefault("settings", {})
    restart_tunnel = False

    if "ntfy_topic" in body:
        topic = str(body.get("ntfy_topic") or "").strip().strip("/")
        settings["ntfy_topic"] = topic or DEFAULT_NTFY_TOPIC

    if "custom_remote_domain" in body:
        dom = str(body.get("custom_remote_domain") or "").strip().rstrip("/")
        if dom and not dom.startswith(("http://", "https://")):
            dom = f"https://{dom}"
        settings["custom_remote_domain"] = dom

    if "cloudflare_tunnel_token" in body:
        new_tok = str(body.get("cloudflare_tunnel_token") or "").strip()
        if new_tok != "********":
            if settings.get("cloudflare_tunnel_token") != new_tok:
                restart_tunnel = True
            settings["cloudflare_tunnel_token"] = new_tok

    if "ngrok_authtoken" in body:
        new_ng = str(body.get("ngrok_authtoken") or "").strip()
        if new_ng != "********":
            settings["ngrok_authtoken"] = new_ng

    save_db(db, broadcast=True)
    try:
        generate_printable_qr_html(admin_url=get_admin_url(), pin=get_configured_pin())
    except Exception:
        pass

    if restart_tunnel and "tunnel_manager" in globals():
        tunnel_manager.request_restart()

    return jsonify({"ok": True, "state": get_public_state()})


@app.route("/api/admin/remote-config/notify", methods=["POST"])
@admin_required
def api_admin_remote_notify() -> Any:
    """Envoie manuellement une notification sur le canal `ntfy.sh` avec le lien 4G actuel."""
    topic = get_ntfy_topic()
    local_url = get_admin_url()
    mdns_url = get_mdns_admin_url()
    remote_url = ""
    if "tunnel_manager" in globals():
        remote_url = str(tunnel_manager.get_info(ntfy_topic=topic).get("public_admin_url") or "")

    if not remote_url:
        return jsonify({
            "ok": False,
            "error": "Le tunnel HTTPS Cloudflare est encore en cours de connexion...",
        }), 400

    ok = publish_to_ntfy(topic, remote_url, local_url, mdns_admin_url=mdns_url, is_reconnect=False)
    if ok:
        return jsonify({
            "ok": True,
            "message": f"Lien envoyé sur https://ntfy.sh/{topic}",
            "state": get_public_state(),
        })
    return jsonify({"ok": False, "error": "Impossible de contacter ntfy.sh"}), 502


_initial_tunnel_connected = False


def on_tunnel_url_change(new_base_url: str) -> None:
    """
    Appelé automatiquement dès que `cloudflared` établit une nouvelle URL publique
    (`https://xxxx.trycloudflare.com`) au démarrage ou après une reconnexion Internet.
    Met à jour la fiche imprimable, notifie `ntfy.sh` et déclenche l'affichage temporaire sur la TV.
    """
    global state_version, _initial_tunnel_connected
    now = time.time()
    state_version = int(now * 1000)
    port = int(os.environ.get("PORT", 5000))
    local_ip = get_local_ip()
    local_admin_url = f"http://{local_ip}:{port}/admin"
    host_local = get_hostname_local()
    mdns_admin_url = f"http://{host_local}:{port}/admin"
    public_admin_url = f"{new_base_url.rstrip('/')}/admin"
    topic = get_ntfy_topic()

    is_reconnect = _initial_tunnel_connected and (now - SERVER_BOOT_EPOCH > 60)
    _initial_tunnel_connected = True

    if is_reconnect:
        qr_overlay_state["trigger_id"] = int(qr_overlay_state.get("trigger_id", 1)) + 1
        qr_overlay_state["reason"] = "reconnect"
        qr_overlay_state["duration_seconds"] = 45
        qr_overlay_state["triggered_at"] = now
    else:
        qr_overlay_state["reason"] = "boot"
        qr_overlay_state["duration_seconds"] = 45
        qr_overlay_state["triggered_at"] = now

    try:
        generate_printable_qr_html(
            admin_url=local_admin_url,
            pin=get_configured_pin(),
            remote_admin_url=public_admin_url,
            ntfy_url=f"https://ntfy.sh/{topic}",
            mdns_admin_url=mdns_admin_url,
        )
    except Exception as exc:
        logger.warning("Erreur mise à jour qr_code_imprimable.html après tunnel : %s", exc)

    try:
        publish_to_ntfy(
            topic,
            public_admin_url,
            local_admin_url,
            mdns_admin_url=mdns_admin_url,
            is_reconnect=is_reconnect,
        )
    except Exception as exc:
        logger.warning("Erreur notification ntfy.sh : %s", exc)

    notify_sse_clients()


# =============================================================================
# PLANIFICATEUR D'ARRIÈRE-PLAN FFF & TUNNEL HTTPS CLOUDFLARE AUTOMATIQUE
# =============================================================================
tunnel_manager = RemoteTunnelManager(
    local_port=int(os.environ.get("PORT", 5000)),
    on_url_change=on_tunnel_url_change,
    get_settings_fn=lambda: load_db().get("settings", {}),
)
def background_scheduler_loop() -> None:
    """
    Boucle démon légère qui :
    1. Synchronise automatiquement les données FFF selon le calendrier.
    2. Publie toutes les heures l'URL active du tunnel et l'IP locale au format JSON
       sur `https://ntfy.sh/asd-durlinsdorf-tunnel-1969` pour le portail de redirection permanent.
    """
    logger.info("Démarrage du planificateur FFF & publication horaire ntfy JSON en tâche de fond.")
    last_hourly_ntfy_json = time.time()
    while True:
        time.sleep(60)
        now = time.time()
        try:
            if should_auto_sync(last_fff_sync_epoch):
                logger.info("Déclenchement automatique de la synchronisation FFF planifiée...")
                run_fff_sync(force_manual=False)
        except Exception as exc:
            logger.error("Erreur dans la boucle de synchronisation FFF : %s", exc)

        # Publication horaire (3600s) du JSON d'auto-redirection sur ntfy.sh/asd-durlinsdorf-tunnel-1969
        if now - last_hourly_ntfy_json >= 3600:
            last_hourly_ntfy_json = now
            try:
                if os.environ.get("ASD_DISABLE_TUNNEL", "0") != "1":
                    t_info = tunnel_manager.get_info(ntfy_topic=get_ntfy_topic())
                    pub_admin = str(t_info.get("public_admin_url") or "")
                    if pub_admin and t_info.get("registered"):
                        publish_tunnel_json_to_ntfy(
                            public_admin_url=pub_admin,
                            local_admin_url=get_admin_url(),
                            mdns_admin_url=get_mdns_admin_url(),
                            reason="hourly_heartbeat",
                        )
            except Exception as exc:
                logger.debug("Erreur publication horaire JSON ntfy : %s", exc)


# Purge immédiate de tout cache QR au démarrage et génération initiale sans ancienne URL de tunnel
qr_b64_cache.clear()
try:
    generate_printable_qr_html(remote_admin_url="")
except Exception as _qr_exc:
    logger.warning("Erreur génération initiale qr_code_imprimable.html : %s", _qr_exc)

scheduler_thread = threading.Thread(target=background_scheduler_loop, daemon=True)
scheduler_thread.start()
if os.environ.get("ASD_DISABLE_TUNNEL", "0") != "1":
    tunnel_manager.start()


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    local_ip = get_local_ip()
    admin_full_url = f"http://{local_ip}:{port}/admin"
    generate_printable_qr_html(admin_url=admin_full_url, pin=get_configured_pin(), remote_admin_url="")
    logger.info("=================================================================")
    logger.info(" TABLEAU DE BORD AS DURLINSDORF (DEPUIS 1969) DÉMARRÉ")
    logger.info(" -> Vue TV 1080p       : http://%s:%d/tv", local_ip, port)
    logger.info(" -> Administration PIN : %s (PIN par défaut: 1969)", admin_full_url)
    logger.info(" -> Fiche QR Imprimable: %s", PRINTABLE_QR_PATH)
    logger.info("=================================================================")
    app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False, threaded=True)
